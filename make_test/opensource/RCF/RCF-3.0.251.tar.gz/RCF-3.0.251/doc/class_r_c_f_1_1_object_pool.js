var class_r_c_f_1_1_object_pool =
[
    [ "enableCaching", "class_r_c_f_1_1_object_pool.html#ab0729ea93ed136d2a991a8f7076c235e", null ],
    [ "disableCaching", "class_r_c_f_1_1_object_pool.html#a102c01a6abae103bf1afc7455bf21387", null ],
    [ "getObj", "class_r_c_f_1_1_object_pool.html#aaa29d1b45f0c9c353b6d8a1ac569150c", null ]
];