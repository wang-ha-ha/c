var searchData=
[
  ['transportprotocol',['TransportProtocol',['../group___r_c_f.html#ga3f88ae1d5008805d5f75151296c2c9e8',1,'RCF']]],
  ['transporttype',['TransportType',['../group___r_c_f.html#ga9d51f89404cea02f9102736f765ae06c',1,'RCF']]]
];
