var searchData=
[
  ['_7ercfinit',['~RcfInit',['../class_r_c_f_1_1_rcf_init.html#a210073eb83b2792638838bd259fb5cc7',1,'RCF::RcfInit']]],
  ['_7ercfserver',['~RcfServer',['../class_r_c_f_1_1_rcf_server.html#ae917adb2cf4d15676a7c78e904a7b128',1,'RCF::RcfServer']]],
  ['_7esspiimpersonator',['~SspiImpersonator',['../class_r_c_f_1_1_sspi_impersonator.html#a12a7d6992adc7d19e0e9ddc22af0308f',1,'RCF::SspiImpersonator']]],
  ['_7ewin32namedpipeimpersonator',['~Win32NamedPipeImpersonator',['../class_r_c_f_1_1_win32_named_pipe_impersonator.html#afd049e1a4cdaae05ec63d2b74237cc9e',1,'RCF::Win32NamedPipeImpersonator']]]
];
