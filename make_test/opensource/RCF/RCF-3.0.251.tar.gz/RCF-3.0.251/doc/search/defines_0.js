var searchData=
[
  ['sf_5fserialize_5fenum_5fclass',['SF_SERIALIZE_ENUM_CLASS',['../_serializer_8hpp.html#a2c4ca9c15976a97da7fc0b74d896e173',1,'Serializer.hpp']]]
];
