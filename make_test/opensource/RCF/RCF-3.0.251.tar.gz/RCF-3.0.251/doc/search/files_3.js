var searchData=
[
  ['globals_2ehpp',['Globals.hpp',['../_globals_8hpp.html',1,'']]]
];
