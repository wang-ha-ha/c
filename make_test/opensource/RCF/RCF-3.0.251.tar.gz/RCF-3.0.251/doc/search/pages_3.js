var searchData=
[
  ['external_20serialization',['External Serialization',['../_external_serialization.html',1,'UserGuide']]],
  ['encryption_20and_20authentication',['Encryption and Authentication',['../_sample_code__encryption.html',1,'SampleCode']]]
];
