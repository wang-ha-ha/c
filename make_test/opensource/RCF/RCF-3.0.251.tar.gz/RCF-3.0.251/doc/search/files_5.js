var searchData=
[
  ['log_2ehpp',['Log.hpp',['../_log_8hpp.html',1,'']]]
];
