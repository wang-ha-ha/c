var searchData=
[
  ['win32certificatelocation',['Win32CertificateLocation',['../group___r_c_f.html#gad63a8841e9cbf54719dabecb687b0b75',1,'RCF']]],
  ['win32certificatestore',['Win32CertificateStore',['../group___r_c_f.html#gad0cb73ef13b805181770256c34ebacd5',1,'RCF']]]
];
