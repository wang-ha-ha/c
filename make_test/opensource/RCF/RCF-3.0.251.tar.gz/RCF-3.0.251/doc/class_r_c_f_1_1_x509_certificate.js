var class_r_c_f_1_1_x509_certificate =
[
    [ "getCertificateName", "class_r_c_f_1_1_x509_certificate.html#a21cc9b878ab934d23ab5a361d9de9bd5", null ],
    [ "getIssuerName", "class_r_c_f_1_1_x509_certificate.html#ae28b4b4759ea09ff2d05fa34087400c1", null ]
];