var class_r_c_f_1_1_ip_server_transport =
[
    [ "setAllowIps", "class_r_c_f_1_1_ip_server_transport.html#a4b976e1fda4673ffcbc45e1b7fdfe25e", null ],
    [ "setDenyIps", "class_r_c_f_1_1_ip_server_transport.html#afc8fd7b87643f42bf9425ab458229227", null ],
    [ "getAllowIps", "class_r_c_f_1_1_ip_server_transport.html#aebdf97f08bffb8ce36f45364e838a679", null ],
    [ "getDenyIps", "class_r_c_f_1_1_ip_server_transport.html#a54ecb93190f7a025a2e5ba88c7fac367", null ],
    [ "getPort", "class_r_c_f_1_1_ip_server_transport.html#a8039d39a935abdf24f5fade86574cac3", null ]
];