var class_r_c_f_1_1_versioning_exception =
[
    [ "getRuntimeVersion", "class_r_c_f_1_1_versioning_exception.html#ab14023c3fb1f3f2f7420940e815d9d6f", null ],
    [ "getArchiveVersion", "class_r_c_f_1_1_versioning_exception.html#a48f2470adbdf84eba2e488cf754d343c", null ],
    [ "clone", "class_r_c_f_1_1_versioning_exception.html#af80de7dbe42163f4c0d2c1beec12371a", null ]
];