var class_r_c_f_1_1_bandwidth_quota =
[
    [ "BandwidthQuota", "class_r_c_f_1_1_bandwidth_quota.html#a61db72e69c07ccde1603d556c9af1ff7", null ],
    [ "setQuota", "class_r_c_f_1_1_bandwidth_quota.html#ae0a83e85e025ff3cf9a1e0bbb3da27b3", null ]
];