var class_r_c_f_1_1_globals =
[
    [ "setDefaultSslImplementation", "class_r_c_f_1_1_globals.html#ac73afd1c6fe86c3982e8a9c4f62b4976", null ],
    [ "getDefaultSslImplementation", "class_r_c_f_1_1_globals.html#ae9d42058cd440890a1fa1fbc83afd39f", null ],
    [ "setDefaultConnectTimeoutMs", "class_r_c_f_1_1_globals.html#aa4542259baff7e6fa6c79d422adea1ef", null ],
    [ "getDefaultConnectTimeoutMs", "class_r_c_f_1_1_globals.html#aaaf9a2d836c6ed94c41141f52029ba2f", null ],
    [ "setDefaultRemoteCallTimeoutMs", "class_r_c_f_1_1_globals.html#a991489cadaaf1f04a0e75866645c85cb", null ],
    [ "getDefaultRemoteCallTimeoutMs", "class_r_c_f_1_1_globals.html#a754250e58258d6887683d2cc3ad6602a", null ],
    [ "setZlibDllName", "class_r_c_f_1_1_globals.html#a4d2ba5ec5d996b48007b3cfd3681fd6b", null ],
    [ "getZlibDllName", "class_r_c_f_1_1_globals.html#a3c903c1e090c3fba280442c99440299b", null ],
    [ "setOpenSslDllName", "class_r_c_f_1_1_globals.html#aaba23a14b21abd79ebe47ddc3f3cf6a8", null ],
    [ "getOpenSslDllName", "class_r_c_f_1_1_globals.html#a7d3fb5fbc81b5c8a32d1cb9283f7e496", null ],
    [ "setOpenSslCryptoDllName", "class_r_c_f_1_1_globals.html#a10ca17120e1dc4971eec9f0e201e1ac0", null ],
    [ "getOpenSslCryptoDllName", "class_r_c_f_1_1_globals.html#a3627aecb3e4804f07effef695be31ffd", null ]
];