var class_r_c_f_1_1_win32_named_pipe_impersonator =
[
    [ "Win32NamedPipeImpersonator", "class_r_c_f_1_1_win32_named_pipe_impersonator.html#ad38a91c19f2d9056ee8548be4da5f6e3", null ],
    [ "~Win32NamedPipeImpersonator", "class_r_c_f_1_1_win32_named_pipe_impersonator.html#afd049e1a4cdaae05ec63d2b74237cc9e", null ],
    [ "revertToSelf", "class_r_c_f_1_1_win32_named_pipe_impersonator.html#a2e0b7ce91a1d99a0c772df3f9f3f0bab", null ]
];