var class_r_c_f_1_1_exception =
[
    [ "clone", "class_r_c_f_1_1_exception.html#ae397b582fea7a425b2a7b1789d7581e4", null ],
    [ "good", "class_r_c_f_1_1_exception.html#a0c3fcc62050f343d3913451541d1fbd5", null ],
    [ "bad", "class_r_c_f_1_1_exception.html#aaef5b81ff8a0846cca7a571b9e1e585a", null ],
    [ "clear", "class_r_c_f_1_1_exception.html#a63823b913180b4c164fad8464513fc04", null ],
    [ "what", "class_r_c_f_1_1_exception.html#a5a2c72e082c71c795a9a906441c5751d", null ],
    [ "getErrorId", "class_r_c_f_1_1_exception.html#ad9a1413bca0a9fb8e901464abcfd6eb8", null ],
    [ "getErrorMessage", "class_r_c_f_1_1_exception.html#a212dab5607ff88c44f99d602480fd6b3", null ]
];