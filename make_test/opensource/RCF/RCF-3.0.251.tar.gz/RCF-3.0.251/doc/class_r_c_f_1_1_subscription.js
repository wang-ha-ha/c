var class_r_c_f_1_1_subscription =
[
    [ "isConnected", "class_r_c_f_1_1_subscription.html#ab54028f04eafc22e50c437275e89428c", null ],
    [ "close", "class_r_c_f_1_1_subscription.html#a87b7aa39854dbfc7f9bf07510fcc5817", null ]
];