var class_r_c_f_1_1_client_transport =
[
    [ "getTransportType", "class_r_c_f_1_1_client_transport.html#ab0f120d4904ba00e6de3e59fe5e477c6", null ],
    [ "setMaxIncomingMessageLength", "class_r_c_f_1_1_client_transport.html#a11aa2132b74185fe2aa6b257fefb3bc4", null ],
    [ "getMaxIncomingMessageLength", "class_r_c_f_1_1_client_transport.html#acc1b999b98becc732a39561dbe1f7a99", null ],
    [ "getLastRequestSize", "class_r_c_f_1_1_client_transport.html#a638f3ea087147060ae9e05d96651dbb4", null ],
    [ "getLastResponseSize", "class_r_c_f_1_1_client_transport.html#a51f3de44c6252460cbbbdb2bba2a430b", null ],
    [ "getRunningTotalBytesSent", "class_r_c_f_1_1_client_transport.html#ab02402c554d3d28cdf7d2fbbba61976c", null ],
    [ "getRunningTotalBytesReceived", "class_r_c_f_1_1_client_transport.html#a5bea246a08cc240082f77e277057000e", null ],
    [ "resetRunningTotals", "class_r_c_f_1_1_client_transport.html#ac2f371480767cfb52fff023e71213293", null ]
];