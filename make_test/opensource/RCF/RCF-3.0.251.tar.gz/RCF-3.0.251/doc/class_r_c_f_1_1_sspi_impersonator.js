var class_r_c_f_1_1_sspi_impersonator =
[
    [ "SspiImpersonator", "class_r_c_f_1_1_sspi_impersonator.html#a940977d8aebd0c163e6d8545cda25e16", null ],
    [ "~SspiImpersonator", "class_r_c_f_1_1_sspi_impersonator.html#a12a7d6992adc7d19e0e9ddc22af0308f", null ],
    [ "revertToSelf", "class_r_c_f_1_1_sspi_impersonator.html#aa91839606ddcc6e204e3cc2b12a99268", null ]
];