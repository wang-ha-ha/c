var class_r_c_f_1_1_file_transfer_progress =
[
    [ "mDownloadPath", "class_r_c_f_1_1_file_transfer_progress.html#aac7fe8a2cf865fb9c88b305bcfd74415", null ],
    [ "mBytesTotalToTransfer", "class_r_c_f_1_1_file_transfer_progress.html#a7c06223dcb8a3f0ed67d1d9b53cc838a", null ],
    [ "mBytesTransferredSoFar", "class_r_c_f_1_1_file_transfer_progress.html#a2e67cd68451c69525cd934b19a0d23fe", null ],
    [ "mServerLimitBps", "class_r_c_f_1_1_file_transfer_progress.html#a1b751f63b6346c39cc7f3b17181cfd62", null ]
];