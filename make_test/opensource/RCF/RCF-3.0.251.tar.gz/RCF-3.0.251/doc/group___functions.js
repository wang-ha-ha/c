var group___functions =
[
    [ "globals", "group___functions.html#gafaaa3e03114ef72ab45876a4bb155b4d", null ],
    [ "enableLogging", "group___functions.html#gae3c2b491aff36faa0807e6ceec4d91dd", null ],
    [ "disableLogging", "group___functions.html#ga4bf396da0a9711d2c7c2c156e57c3a3c", null ]
];