var class_r_c_f_1_1_file_transfer_options =
[
    [ "mBandwidthLimitBps", "class_r_c_f_1_1_file_transfer_options.html#ab065964692da6577dd82b01949e37e9d", null ],
    [ "mBandwidthQuotaPtr", "class_r_c_f_1_1_file_transfer_options.html#a8ae457362ca43356b770fc17ea02a854", null ],
    [ "mStartPos", "class_r_c_f_1_1_file_transfer_options.html#a4530809ec705f7f36275171fb8ab7dca", null ],
    [ "mEndPos", "class_r_c_f_1_1_file_transfer_options.html#ae51380035dcb69d391e50be5ecc36702", null ],
    [ "mProgressCallback", "class_r_c_f_1_1_file_transfer_options.html#a6b7f8fd92eba852b76b192818425a92e", null ]
];