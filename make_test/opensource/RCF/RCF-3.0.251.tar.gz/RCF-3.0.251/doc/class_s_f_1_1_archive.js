var class_s_f_1_1_archive =
[
    [ "isRead", "class_s_f_1_1_archive.html#aad43074aee814732942093aa95f761f1", null ],
    [ "isWrite", "class_s_f_1_1_archive.html#a43cc777d18eff8c761ec5133603ba680", null ],
    [ "getRuntimeVersion", "class_s_f_1_1_archive.html#ad138ae8e117d9a159ef9cf199bf380c1", null ],
    [ "getArchiveVersion", "class_s_f_1_1_archive.html#ab57895175bdee4ff0b1e2018a06c520b", null ]
];