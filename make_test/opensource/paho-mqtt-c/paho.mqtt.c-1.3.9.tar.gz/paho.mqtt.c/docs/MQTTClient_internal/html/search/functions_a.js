var searchData=
[
  ['utf8_5fchar_5fvalidate_842',['UTF8_char_validate',['../utf-8_8c.html#a9727caa7417e6bed8cfad4121a22628d',1,'utf-8.c']]],
  ['utf8_5fvalidate_843',['UTF8_validate',['../utf-8_8c.html#ad2012627fca4b4bdd9f67bde49b0d1cb',1,'utf-8.c']]],
  ['utf8_5fvalidatestring_844',['UTF8_validateString',['../utf-8_8c.html#a4f3cf77538d867bb5b421bcb687dccdf',1,'utf-8.c']]]
];
