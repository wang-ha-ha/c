var searchData=
[
  ['synchronous_20publication_20example_608',['Synchronous publication example',['../pubsync.html',1,'']]],
  ['subscription_20wildcards_609',['Subscription wildcards',['../wildcard.html',1,'']]]
];
