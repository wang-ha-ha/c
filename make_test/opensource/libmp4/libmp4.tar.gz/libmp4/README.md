# libmp4 - MP4 file library

libmp4 is a C library to handle MP4 files (ISO base media file format, see ISO/IEC 14496-12).
It is mainly targeted to be used with videos produced by Parrot Drones (Bebop, Bebop2, Disco, etc.).
